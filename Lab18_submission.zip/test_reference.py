"""Classroom reference tests, not evidence of a successful SEC download."""
from datetime import date, timedelta
import unittest

from test_rules import analyze, fixture
from edgar import TAGS, audit_memo
from verify_reference import reference_rows, compare_cost, compare_jpm


def classroom_fixture():
    facts = {'cik': 0, 'entityName': 'USER-SUPPLIED CLASSROOM FIXTURE, NOT SEC DATA', 'facts': {'us-gaap': {}}}
    start = '2021-08-30'
    for row in reference_rows():
        end = row['fiscal_year_end']
        for metric, tags in TAGS.items():
            f = {'end': end, 'form': '10-K', 'filed': '2026-10-01', 'accn': 'TEST',
                 'val': int(row[metric]) * 1_000_000}
            if metric != 'equity':
                f['start'] = start
            facts['facts']['us-gaap'].setdefault(tags[0], {'units': {'USD': []}})['units']['USD'].append(f)
        start = (date.fromisoformat(end) + timedelta(days=1)).isoformat()
    return facts


class ReferenceTests(unittest.TestCase):
    def test_cost_all_cells_and_checks(self):
        self.assertEqual(compare_cost(analyze(classroom_fixture(), 'TEST')), [])

    def test_reference_comparison_detects_changed_input(self):
        facts = classroom_fixture()
        facts['facts']['us-gaap']['NetIncomeLoss']['units']['USD'][0]['val'] += 1_000_000
        self.assertTrue(compare_cost(analyze(facts, 'TEST')))

    def test_jpm_style_absent_capex_not_zero(self):
        facts = fixture()
        del facts['facts']['us-gaap']['PaymentsToAcquirePropertyPlantAndEquipment']
        self.assertEqual(compare_jpm(analyze(facts, 'TEST')), [])

    def test_hand_typed_roe(self):
        report = analyze(classroom_fixture(), 'TEST')
        flags = audit_memo('ROE was 40.0%.', report)
        self.assertEqual([f['number'] for f in flags], ['40.0%'])


if __name__ == '__main__':
    unittest.main()
