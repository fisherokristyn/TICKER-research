---
name: buffett-edgar
description: Analyze a US company's business using five years of SEC 10-K facts, deterministic Buffett checks, and a short Buffett-inspired memo. Use for ticker-based business-quality analysis, not stock-price valuation.
---

# Buffett EDGAR business review

Run the bundled script; never calculate financial numbers mentally. Do not install FAskills or use its data services. Its [Buffett page](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/warren_buffett.md) supplies qualitative ideas only: business understanding, moat durability, and management's capital allocation. Write in a plain, patient, Buffett-inspired first-person voice; identify the memo as an AI simulation, not Buffett's actual opinion.

## Run

Get the user's real name and email for the SEC User-Agent; never invent contact details. Set SEC_USER_AGENT to `Name email`, or pass `--user-agent "Name email"`.

From this skill directory:

```powershell
python scripts/edgar.py COST --output-dir C:/Users/krist/work/lab18/reports
```

Substitute the requested ticker. The script downloads only SEC ticker mappings and company facts, without API keys, caches raw responses, and prints and saves the same report. Read the complete printed report before writing a memo. Preserve the JSON, text report, and original cached JSON for auditability.

## Rules

- Only form `10-K`, excluding `10-K/A` and `10-Q`. Select the last five actual annual period-end dates, not the `fy` field (comparative facts carry later filing fiscal years).
- Annual flows require a start and end spanning 350–380 inclusive days, accommodating 52/53-week years. Do not sum quarters or use multi-year totals. Short transition periods are excluded and disclosed.
- USD only. Use these tags, in order per metric: revenue `RevenueFromContractWithCustomerExcludingAssessedTax`, then `Revenues`; net income `NetIncomeLoss`; operating cash flow `NetCashProvidedByUsedInOperatingActivities`; capital spending `PaymentsToAcquirePropertyPlantAndEquipment`, then `PaymentsToAcquireProductiveAssets`; equity `StockholdersEquity`.
- Within the first available permitted tag for a period, the latest 10-K filing wins. For flows, require the same annual start and end as the selected fiscal period. Equity is an instant at that year-end. Conflicting values in the same latest filing are not guessed.
- ROE = net income / year-end equity, not average equity. Owner earnings = operating cash flow - capital spending, the classroom proxy; do not estimate maintenance spending. Show the actual input tags for calculated metrics, which have no standalone XBRL tag.
- Missing source value: `not found`. Owner earnings with a missing cash-flow or capital-spending input also prints `not found`, as required by the JPM probe. ROE with a missing input or nonpositive equity, and any check with a missing required input: `not known`. No estimates. Liabilities/equity is outside this assignment's required output; if added later, nonpositive equity must yield `not known`.
- Code checks: ROE >= 15% in every year; owner earnings > 0 in every year; last owner earnings > first owner earnings. Require five years. Do not infer a pass from incomplete coverage, round before comparing, or treat a missing value as zero.

## Memo

Save `<TICKER>_memo.md` beside the generated report. Choose **own the business**, **watch it**, or **pass** based on judgment, not a mechanical mapping from check results. Judge the business only; no price, valuation, forecasts, target prices, invented scores, or margin-of-safety claims. Use only numerical strings printed in the report, with their correct meaning and period. Avoid numbered lists and spelled-out numerical quantities. Discuss the evidence, what it cannot establish about moat and management, and what would change your mind. Do not claim the numerical screen proves qualitative strengths.

Read business descriptions only from an actual SEC 10-K if deeper qualitative evidence is needed; cite the filing and keep unprinted numbers out of the memo. Without that evidence, state the qualitative uncertainty instead of filling it with remembered company facts. If owner earnings is missing, explicitly say the memo cannot judge owner earnings from the permitted data; do not treat a bank's missing spending tag as zero spending.

Validate the saved memo:

```powershell
python scripts/edgar.py --audit-memo C:/Users/krist/work/lab18/reports/COST_memo.md --report C:/Users/krist/work/lab18/reports/COST.json
```

Fix every unsupported numerical occurrence and rerun the audit. A clean number audit checks printed-number membership only, not whether a number is attached to the correct claim. Review that separately. The Streamlit app reads the saved AI memo; it does not substitute a templated memo for model judgment.

Sources: [Codex skills](https://learn.chatgpt.com/docs/build-skills), [EDGAR API documentation](https://www.sec.gov/search-filings/edgar-application-programming-interfaces).
