"""Three model memos over one computed evidence snapshot."""
import re
import pandas as pd
import streamlit as st

from edgar import audit_memo


def verdict_from_memo(memo):
    heading = next((line for line in memo.splitlines() if line.startswith('# ')), '')
    match = re.search(r'(Own the business|Watch it|Pass)\s*$', heading, re.I)
    return match.group(1).lower() if match else 'not provided'


def render_panel(report, reports, ticker, buffett_memo):
    st.subheader('Investor panel')
    st.caption('The same SEC facts and periods; different questions. These are AI simulations, not independent expert endorsements.')
    if 'panel_checks' not in report:
        st.info('Refresh SEC facts to add the Graham and Burry checks to this older report.')
        return
    checks = [{'Investor': name, 'Check': label, 'Result': status}
              for name, values in report['panel_checks'].items() for label, status in values.items()]
    st.dataframe(pd.DataFrame(checks), hide_index=True, width='stretch', key='panel_checks')
    st.caption('A check result is computed. A verdict is the judgment written in that investor’s memo.')
    all_flags = []
    verdicts = []
    for investor, column in zip(('Buffett', 'Graham', 'Burry'), st.columns(3, border=True)):
        with column:
            st.subheader(investor)
            verdict_slot = st.empty()
            content_slot = st.container()
            if investor == 'Buffett':
                memo = buffett_memo
                st.caption('Edit or upload the Buffett memo in the original editor above.')
            else:
                slug = investor.lower()
                memo_path = reports / f'{ticker}_{slug}_memo.md'
                binding_path = reports / f'{ticker}_{slug}_memo.snapshot'
                saved = memo_path.read_text(encoding='utf-8-sig') if memo_path.exists() else ''
                upload = st.file_uploader(f'Load {investor} memo', type=['md'], key=f'{slug}_upload_{ticker}')
                try:
                    initial = upload.getvalue().decode('utf-8-sig') if upload else saved
                except UnicodeDecodeError:
                    st.error('Use a UTF-8 Markdown memo.')
                    initial = ''
                memo = st.text_area(f'{investor} memo text', value=initial, height=200,
                                    key=f"{slug}_memo_{ticker}_{report['snapshot_id']}_{upload.file_id if upload else 'saved'}")
                if memo and (not binding_path.exists() or binding_path.read_text().strip() != report['snapshot_id']):
                    st.warning('Review this memo against the current facts snapshot before saving.')
                flags = audit_memo(memo, report)
                if st.button(f'Save {investor} memo', disabled=not memo.strip() or bool(flags)):
                    memo_path.write_text(memo, encoding='utf-8')
                    binding_path.write_text(report['snapshot_id'], encoding='utf-8')
                    st.success('Memo saved for this snapshot.')
                if memo:
                    st.download_button(f'Download {investor} memo', memo, file_name=memo_path.name, mime='text/markdown')
            verdict = verdict_from_memo(memo)
            verdicts.append({'Investor': investor, 'Verdict': verdict})
            verdict_slot.markdown(f'**Verdict: {verdict}**')
            if memo:
                with content_slot:
                    st.markdown(memo)
                all_flags.extend({'Investor': investor, **flag} for flag in audit_memo(memo, report))
            else:
                with content_slot:
                    st.info(f'Use ${investor.lower()}-edgar on {ticker} to write this memo from the shared report.')
    st.subheader('Number audit across all memos')
    if all_flags:
        st.error(f'{len(all_flags)} unsupported numerical occurrence(s) across the panel.')
        st.dataframe(pd.DataFrame(all_flags), hide_index=True, width='stretch', key='panel_number_flags')
    else:
        st.success('No unsupported numerical occurrences in the available panel memos.')
    if any(v['Verdict'] == 'not provided' for v in verdicts):
        st.warning('The panel is incomplete: a memo or its verdict heading is missing.')
    st.caption('Numbers are checked against the shared printed values. This does not verify the meaning of a claim or make agreement independent evidence.')
    st.download_button('Download panel checks', pd.DataFrame(checks).to_csv(index=False),
                       file_name=f'{ticker}_panel_checks.csv', mime='text/csv')
