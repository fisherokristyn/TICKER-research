"""Keyless SEC facts, deterministic classroom metrics, and a conservative memo audit."""
from __future__ import annotations

import argparse
from datetime import date, datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

# Companion skills use this exact report; they never download competing snapshots.
SKILLS_ROOT = Path(__file__).resolve().parents[2]
for companion in ('graham-edgar', 'burry-edgar'):
    sys.path.insert(0, str(SKILLS_ROOT / companion / 'scripts'))
from graham_checks import check_graham, current_ratio_threshold
from burry_checks import check_burry

TICKERS_URL = 'https://www.sec.gov/files/company_tickers.json'
FACTS_URL = 'https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json'
TAGS = {
    'revenue': ['RevenueFromContractWithCustomerExcludingAssessedTax', 'Revenues'],
    'net_income': ['NetIncomeLoss'],
    'operating_cash_flow': ['NetCashProvidedByUsedInOperatingActivities'],
    'capital_spending': ['PaymentsToAcquirePropertyPlantAndEquipment', 'PaymentsToAcquireProductiveAssets'],
    'equity': ['StockholdersEquity'],
    'liabilities': ['Liabilities'],
    'current_assets': ['AssetsCurrent'],
    'current_liabilities': ['LiabilitiesCurrent'],
}
LABELS = {k: k.replace('_', ' ').title() for k in TAGS}
LABELS.update(roe='ROE', owner_earnings='Owner Earnings', current_ratio='Current Ratio', liabilities_to_equity='Liabilities / Equity')


def ticker_symbol(value):
    value = value.strip().upper()
    if not re.fullmatch(r'[A-Z][A-Z0-9.-]{0,14}', value):
        raise ValueError('Enter a ticker containing letters, digits, dots or hyphens.')
    return value


def validate_user_agent(value):
    value = value.strip()
    if '\n' in value or '\r' in value or not re.fullmatch(r'.+\s+[^\s@]+@[^\s@]+\.[^\s@]+', value):
        raise ValueError('Provide your real name and email as the SEC User-Agent: Name email@domain.com')
    return value


def fetch_json(url, user_agent, cache_path, refresh=False):
    user_agent = validate_user_agent(user_agent)
    cache_path = Path(cache_path)
    if not refresh and cache_path.exists() and time.time() - cache_path.stat().st_mtime < 86400:
        return json.loads(cache_path.read_text(encoding='utf-8'))
    for attempt in range(3):
        time.sleep(0.25 + attempt)
        try:
            request = Request(url, headers={'User-Agent': user_agent, 'Accept': 'application/json'})
            with urlopen(request, timeout=45) as response:
                raw = response.read()
            result = json.loads(raw)
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            cache_path.write_bytes(raw)
            return result
        except HTTPError as exc:
            if exc.code not in (429, 500, 502, 503, 504) or attempt == 2:
                raise RuntimeError(f'SEC returned HTTP {exc.code} for {url}. No substitute data was used.') from exc
        except (URLError, TimeoutError) as exc:
            if attempt == 2:
                raise RuntimeError(f'SEC connection failed: {exc}. No substitute data was used.') from exc
    raise RuntimeError('SEC download failed.')


def is_annual(fact):
    if fact.get('form') != '10-K' or not fact.get('start') or not fact.get('end'):
        return False
    days = (date.fromisoformat(fact['end']) - date.fromisoformat(fact['start'])).days + 1
    return 350 <= days <= 380


def numeric(value):
    return isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)


def period_list(facts):
    # Inspect all consolidated standard concepts so missing required tags do not hide a year.
    candidates = {}
    for concept in facts.get('facts', {}).get('us-gaap', {}).values():
        for fact in concept.get('units', {}).get('USD', []):
            if is_annual(fact):
                end = fact['end']
                rank = (fact.get('filed', ''), fact.get('accn', ''), fact['start'])
                if end not in candidates or rank > candidates[end][0]:
                    candidates[end] = (rank, fact['start'])
    return [(candidates[end][1], end) for end in sorted(candidates)[-5:]]


def source_value(facts, tags, start, end, instant=False):
    gaap = facts.get('facts', {}).get('us-gaap', {})
    for tag in tags:
        matching = [f for f in gaap.get(tag, {}).get('units', {}).get('USD', [])
                    if f.get('form') == '10-K' and f.get('end') == end
                    and (not f.get('start') if instant else is_annual(f) and f['start'] == start)
                    and numeric(f.get('val'))]
        if not matching:
            continue
        latest = max((f.get('filed', ''), f.get('accn', '')) for f in matching)
        winning = [f for f in matching if (f.get('filed', ''), f.get('accn', '')) == latest]
        values = {Decimal(str(f['val'])) for f in winning}
        if len(values) != 1:
            return {'value': None, 'display': 'not found', 'tag': 'us-gaap:' + tag,
                    'reason': 'Conflicting values in the latest filing; no estimate.'}
        f = winning[0]
        return {'value': f['val'], 'display': format_money(f['val']), 'tag': 'us-gaap:' + tag,
                'filed': f.get('filed'), 'accession': f.get('accn'), 'start': f.get('start'),
                'end': end, 'unit': 'USD'}
    return {'value': None, 'display': 'not found', 'tag': 'not found',
            'searched_tags': ['us-gaap:' + t for t in tags]}


def format_money(value):
    d = Decimal(str(value))
    return format(d, ',.0f') if d == d.to_integral_value() else format(d, ',f')


def calc(inputs, kind):
    ratio = kind != 'owner_earnings'
    tags = (' / ' if ratio else ' - ').join(v['tag'] for v in inputs)
    if any(v['value'] is None for v in inputs) or (ratio and inputs[1]['value'] <= 0):
        return {'value': None, 'display': 'not found' if kind == 'owner_earnings' else 'not known',
                'tag': tags, 'derived': True}
    a, b = (Decimal(str(v['value'])) for v in inputs)
    result = a / b if ratio else a - b
    display = (str((result * 100).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)) + '%'
               if kind == 'roe' else str(result.quantize(Decimal('.01'), rounding=ROUND_HALF_UP)) if ratio else format_money(result))
    return {'value': float(result) if ratio else int(result) if result == result.to_integral_value() else float(result),
            'display': display, 'tag': tags, 'derived': True}


def checks_for(rows):
    complete = len(rows) == 5
    def check(key, condition):
        if not complete or any(row[key]['value'] is None for row in rows):
            return 'not known'
        return 'pass' if condition() else 'fail'
    return {
        'ROE >= 15% every year': check('roe', lambda: all(
            Decimal(str(r['net_income']['value'])) >= Decimal('.15') * Decimal(str(r['equity']['value'])) for r in rows)),
        'Owner earnings > 0 every year': check('owner_earnings', lambda: all(r['owner_earnings']['value'] > 0 for r in rows)),
        'Owner earnings grew, first year to last': (
            'not known' if not complete or any(r['owner_earnings']['value'] is None for r in (rows[0], rows[-1]))
            else 'pass' if rows[-1]['owner_earnings']['value'] > rows[0]['owner_earnings']['value'] else 'fail'),
    }


def build_year_row(facts, start, end):
    """Select reported inputs for an annual period, then compute its derived metrics."""
    row = {'fiscal_year_end': end, 'annual_start': start}
    for metric, tags in TAGS.items():
        row[metric] = source_value(facts, tags, start, end, instant=(metric in {'equity', 'liabilities', 'current_assets', 'current_liabilities'}))
    row['roe'] = calc([row['net_income'], row['equity']], 'roe')
    row['owner_earnings'] = calc([row['operating_cash_flow'], row['capital_spending']], 'owner_earnings')
    row['current_ratio'] = calc([row['current_assets'], row['current_liabilities']], 'current_ratio')
    row['liabilities_to_equity'] = calc([row['liabilities'], row['equity']], 'liabilities_to_equity')
    return row


def analyze(facts, ticker):
    rows = [build_year_row(facts, start, end) for start, end in period_list(facts)]
    if not rows:
        raise ValueError('No annual USD facts from 10-K filings were found. No estimates produced.')
    result = {'ticker': ticker_symbol(ticker), 'company': facts.get('entityName', ticker),
              'cik': facts.get('cik'), 'rows': rows, 'checks': checks_for(rows),
              'retrieved_at': datetime.now(timezone.utc).isoformat(),
              'source': FACTS_URL.format(cik=int(facts['cik'])),
              'raw_sha256': hashlib.sha256(json.dumps(facts, sort_keys=True).encode()).hexdigest()}
    threshold = current_ratio_threshold()
    result['graham_current_ratio_threshold'] = format(threshold.normalize(), 'f')
    result['panel_checks'] = {'Buffett': result['checks'], 'Graham': check_graham(rows, threshold), 'Burry': check_burry(rows)}
    result['report_text'] = render_report(result)
    # Only printed data values, dates, explicit year labels, and check thresholds are allowed.
    printed_values = ['5', '15%', '0', '2', result['graham_current_ratio_threshold']]
    for row in rows:
        printed_values += [row['fiscal_year_end'], row['fiscal_year_end'][:4]]
        printed_values += [row[k]['display'] for k in LABELS]
    result['printed_values'] = printed_values
    result['snapshot_id'] = hashlib.sha256(result['report_text'].encode()).hexdigest()
    return result


def render_report(report):
    lines = [f"{report['company']} ({report['ticker']})", 'Last 5 fiscal years | USD; ROE in percent',
             '10-K only. Annual flows: 350-380 days. Latest filing within the first available permitted tag wins.',
             'Owner earnings is the classroom operating-cash-flow-minus-capital-spending proxy.', '']
    if len(report['rows']) < 5:
        lines += ['Fewer than 5 annual periods found. Checks are not known.', '']
    for row in report['rows']:
        lines.append(f"Fiscal year end: {row['fiscal_year_end']} (FY{row['fiscal_year_end'][:4]})")
        for key, label in LABELS.items():
            cell = row[key]
            provenance = f"; filed {cell['filed']}; accession {cell['accession']}" if cell.get('filed') else ''
            lines.append(f"  {label}: {cell['display']} | {cell['tag']}{provenance}")
        lines.append('')
    lines += [f'{label}: {status}' for label, status in report['checks'].items()]
    lines += ['', 'Graham current-ratio threshold: ' + report['graham_current_ratio_threshold']]
    for investor in ('Graham', 'Burry'):
        lines += ['', investor + ' checks:']
        lines += [f'{label}: {status}' for label, status in report['panel_checks'][investor].items()]
    return '\n'.join(lines) + '\n'


# Strict audit: units and percentage marks matter. Dates are a single token.
NUMBER = re.compile(r'\d{4}-\d{2}-\d{2}|(?<![\d.])[-+−]?\d[\d,]*(?:\.\d+)?(?:[eE][+-]?\d+)?(?:\s*(?:%|percent\b|percentage\s+points\b|billion\b|million\b|thousand\b|trillion\b|[BMK]\b))?', re.I)
WORDS = re.compile(r'\b(?:zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|billion|trillion|first|second|third|fourth|fifth|half|twice|double|doubled|triple|tripled)\b', re.I)


def normal_number(token):
    return token.replace(',', '').replace('−', '-').strip().lower()


def audit_memo(memo, report):
    allowed = {normal_number(t) for value in report['printed_values'] for t in NUMBER.findall(value)}
    found = []
    for line_no, line in enumerate(memo.splitlines(), 1):
        numeric_spans = []
        for match in NUMBER.finditer(line):
            numeric_spans.append(match.span())
            if normal_number(match.group()) not in allowed:
                found.append({'line': line_no, 'number': match.group(), 'context': line.strip()})
        for match in WORDS.finditer(line):
            if not any(a <= match.start() < b for a, b in numeric_spans):
                found.append({'line': line_no, 'number': match.group(), 'context': line.strip()})
    return found


def build(ticker, user_agent, output_dir, refresh=False):
    ticker = ticker_symbol(ticker)
    output_dir = Path(output_dir)
    mapping = fetch_json(TICKERS_URL, user_agent, output_dir / 'cache' / 'company_tickers.json', refresh)
    entry = next((v for v in mapping.values() if v['ticker'].upper() == ticker), None)
    if entry is None:
        raise ValueError(f'{ticker} was not found in the SEC ticker mapping.')
    cik = int(entry['cik_str'])
    facts = fetch_json(FACTS_URL.format(cik=cik), user_agent, output_dir / 'cache' / f'CIK{cik:010d}.json', refresh)
    report = analyze(facts, ticker)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / f'{ticker}.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    (output_dir / f'{ticker}_facts.txt').write_text(report['report_text'], encoding='utf-8')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('ticker', nargs='?')
    parser.add_argument('--user-agent', default=os.getenv('SEC_USER_AGENT', ''))
    parser.add_argument('--output-dir', default='reports')
    parser.add_argument('--refresh', action='store_true')
    parser.add_argument('--audit-memo', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    try:
        if args.audit_memo:
            if not args.report:
                parser.error('--report is required for memo auditing')
            flags = audit_memo(args.audit_memo.read_text(encoding='utf-8-sig'), json.loads(args.report.read_text(encoding='utf-8')))
            print(json.dumps({'unsupported_numbers': flags}, indent=2))
            return 1 if flags else 0
        if not args.ticker:
            parser.error('ticker is required')
        report = build(args.ticker, args.user_agent, args.output_dir, args.refresh)
        print(report['report_text'])
        return 0
    except (ValueError, RuntimeError, OSError, KeyError) as exc:
        print(f'Error: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
