"""UI integration checks in a temporary folder, never the user's reports."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest
from test_rules import fixture, analyze
from test_reference import classroom_fixture
from edgar import LABELS

APP = str(Path(__file__).parent / 'app.py')


class AppIntegration(unittest.TestCase):
    def test_table_checks_memo_and_flagging(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            report = analyze(classroom_fixture(), 'COST')
            (root / 'COST.json').write_text(json.dumps(report), encoding='utf-8')
            (root / 'COST_memo.md').write_text('Watch it. ROE was ' + report['rows'][0]['roe']['display'] + '.', encoding='utf-8')
            (root / 'COST_memo.snapshot').write_text(report['snapshot_id'])
            with patch.dict(os.environ, {'BUFFETT_REPORTS_DIR': directory}):
                at = AppTest.from_file(APP, default_timeout=30).run()
                self.assertFalse(at.exception)
                self.assertEqual(len(at.metric), 3)
                self.assertEqual(at.dataframe[0].value.shape, (5, len(LABELS) + 1))
                self.assertEqual([v.value for v in at.metric], ['PASS', 'PASS', 'PASS'])
                at.text_area[0].set_value('Watch it. ROE was 40.0%.').run()
                self.assertFalse(at.exception)
                self.assertIn('1 unsupported', at.error[0].value)
                self.assertEqual(at.dataframe[-1].value.iloc[0]['number'], '40.0%')
                self.assertTrue(next(b for b in at.button if b.label == 'Save reviewed memo').disabled)
                at.text_input(key='ticker').set_value('INVALID/').run()
                self.assertFalse(at.exception)
                self.assertTrue(at.warning)

    def test_no_data_does_not_invent_report(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.dict(os.environ, {'BUFFETT_REPORTS_DIR': directory}):
                at = AppTest.from_file(APP, default_timeout=30).run()
                self.assertFalse(at.exception)
                self.assertFalse(at.dataframe)
                self.assertTrue(at.info)


if __name__ == '__main__':
    unittest.main()
