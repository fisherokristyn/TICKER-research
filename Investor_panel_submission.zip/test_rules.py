"""Offline regression tests. Synthetic data never enters the COST reports."""
import copy
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).parent / 'buffett-edgar' / 'scripts'))
from edgar import analyze, audit_memo, is_annual


def fixture():
    facts = {'cik': 1, 'entityName': 'Synthetic test entity', 'facts': {'us-gaap': {}}}
    values = {'Revenues': 1000, 'NetIncomeLoss': 20, 'NetCashProvidedByUsedInOperatingActivities': 50,
              'PaymentsToAcquirePropertyPlantAndEquipment': 10, 'StockholdersEquity': 100}
    for tag, value in values.items():
        entries = []
        for year in range(2022, 2027):
            f = {'end': f'{year}-12-31', 'filed': f'{year+1}-02-01', 'accn': f'{year}-a',
                 'form': '10-K', 'val': value, 'fy': 2028, 'fp': 'FY'}
            if tag != 'StockholdersEquity':
                f['start'] = f'{year}-01-01'
            if tag == 'NetCashProvidedByUsedInOperatingActivities':
                f['val'] += year - 2022
            entries.append(f)
        facts['facts']['us-gaap'][tag] = {'units': {'USD': entries}}
    return facts


class Rules(unittest.TestCase):
    def test_year_end_not_filing_year_and_checks(self):
        r = analyze(fixture(), 'TEST')
        self.assertEqual([x['fiscal_year_end'] for x in r['rows']], [f'{y}-12-31' for y in range(2022, 2027)])
        self.assertEqual(list(r['checks'].values()), ['pass', 'pass', 'pass'])
        self.assertEqual(r['rows'][0]['owner_earnings']['value'], 40)
        self.assertEqual(r['rows'][0]['roe']['display'], '20.00%')

    def test_annual_periods_and_latest_filing(self):
        f = fixture()
        entries = f['facts']['us-gaap']['NetIncomeLoss']['units']['USD']
        for changes in [{'start': '2026-10-01', 'val': 999}, {'start': '2025-01-01', 'val': 888},
                        {'form': '10-Q', 'val': 777}, {'form': '10-K/A', 'val': 666}]:
            entries.append({**entries[4], **changes, 'filed': '2028-01-01'})
        entries.append({**entries[0], 'filed': '2029-01-01', 'val': 25})
        r = analyze(f, 'TEST')
        self.assertEqual(r['rows'][-1]['net_income']['value'], 20)
        self.assertEqual(r['rows'][0]['net_income']['value'], 25)
        self.assertTrue(is_annual({'form': '10-K', 'start': '2022-08-29', 'end': '2023-09-03'}))

    def test_fallback_priority(self):
        f = fixture()
        f['facts']['us-gaap']['RevenueFromContractWithCustomerExcludingAssessedTax'] = copy.deepcopy(f['facts']['us-gaap']['Revenues'])
        f['facts']['us-gaap']['RevenueFromContractWithCustomerExcludingAssessedTax']['units']['USD'][0]['val'] = 1234
        self.assertEqual(analyze(f, 'TEST')['rows'][0]['revenue']['value'], 1234)

    def test_missing_nonpositive_and_incomplete(self):
        f = fixture()
        f['facts']['us-gaap']['StockholdersEquity']['units']['USD'][0]['val'] = 0
        f['facts']['us-gaap']['NetCashProvidedByUsedInOperatingActivities']['units']['USD'].pop(2)
        r = analyze(f, 'TEST')
        self.assertEqual(r['rows'][0]['roe']['display'], 'not known')
        self.assertEqual(r['rows'][2]['operating_cash_flow']['display'], 'not found')
        self.assertEqual(r['rows'][2]['owner_earnings']['display'], 'not found')
        self.assertEqual(list(r['checks'].values()), ['not known', 'not known', 'pass'])
        f['facts']['us-gaap']['StockholdersEquity']['units']['USD'][0]['val'] = -100
        self.assertEqual(analyze(f, 'TEST')['rows'][0]['roe']['display'], 'not known')

    def test_threshold_no_rounding_and_zero_owner_earnings(self):
        f = fixture()
        f['facts']['us-gaap']['NetIncomeLoss']['units']['USD'][0]['val'] = 14.9999
        f['facts']['us-gaap']['NetCashProvidedByUsedInOperatingActivities']['units']['USD'][0]['val'] = 10
        r = analyze(f, 'TEST')
        self.assertEqual(r['rows'][0]['roe']['display'], '15.00%')
        self.assertEqual(list(r['checks'].values()), ['fail', 'fail', 'pass'])

    def test_memo_audit(self):
        r = analyze(fixture(), 'TEST')
        self.assertEqual(audit_memo('At 2022-12-31: $1,000 revenue and 20.00% ROE.', r), [])
        flags = audit_memo('999 and 999; -20; 20%; 1,000 million; twenty years; 2027-12-31.', r)
        self.assertEqual(len(flags), 7)
        self.assertEqual([v['number'] for v in flags].count('999'), 2)

    def test_missing_endpoint_and_fewer_years(self):
        f = fixture()
        f['facts']['us-gaap']['NetCashProvidedByUsedInOperatingActivities']['units']['USD'].pop(0)
        self.assertEqual(list(analyze(f, 'TEST')['checks'].values()), ['pass', 'not known', 'not known'])
        for concept in f['facts']['us-gaap'].values():
            concept['units']['USD'] = [x for x in concept['units']['USD'] if x['end'] != '2022-12-31']
        self.assertTrue(all(v == 'not known' for v in analyze(f, 'TEST')['checks'].values()))

    def test_conflict_not_guessed_and_instant_equity(self):
        f = fixture()
        net = f['facts']['us-gaap']['NetIncomeLoss']['units']['USD']
        net.append({**net[0], 'val': 999})
        equity = f['facts']['us-gaap']['StockholdersEquity']['units']['USD']
        equity.append({**equity[0], 'start': '2022-01-01', 'filed': '2029-01-01', 'val': 999})
        r = analyze(f, 'TEST')
        self.assertEqual(r['rows'][0]['net_income']['display'], 'not found')
        self.assertEqual(r['rows'][0]['equity']['value'], 100)


if __name__ == '__main__':
    unittest.main()
