"""Verify saved SEC reports, AI memos, and the actual Streamlit warning."""
import json
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'buffett-edgar' / 'scripts'))
from edgar import LABELS, audit_memo
from verify_reference import compare_cost, compare_jpm


def main():
    evidence = {'source': 'Downloaded SEC reports, not classroom fixtures', 'companies': {}}
    for ticker, comparator in [('COST', compare_cost), ('JPM', compare_jpm)]:
        report_path = ROOT / 'reports' / f'{ticker}.json'
        report = json.loads(report_path.read_text(encoding='utf-8'))
        memo = (ROOT / 'reports' / f'{ticker}_memo.md').read_text(encoding='utf-8')
        mismatches = comparator(report)
        assert not mismatches, mismatches
        flags = audit_memo(memo, report)
        assert not flags, flags
        if ticker == 'JPM':
            assert 'cannot judge owner earnings' in memo
        (ROOT / 'reports' / f'{ticker}_memo.snapshot').write_text(report['snapshot_id'], encoding='utf-8')
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder)
            (target / f'{ticker}.json').write_text(json.dumps(report), encoding='utf-8')
            (target / f'{ticker}_memo.md').write_text(memo, encoding='utf-8')
            (target / f'{ticker}_memo.snapshot').write_text(report['snapshot_id'], encoding='utf-8')
            with patch.dict(os.environ, {'BUFFETT_REPORTS_DIR': folder}):
                app = AppTest.from_file(str(ROOT / 'app.py'), default_timeout=30).run()
                if ticker != 'COST':
                    app.text_input(key='ticker').set_value(ticker).run()
                assert not app.exception, app.exception
                assert app.dataframe[0].value.shape == (5, len(LABELS) + 1)
                assert len(app.metric) == 3
                assert not app.error, app.error
                result = {'reference_match': True, 'memo_number_audit': 'pass',
                          'checks': report['checks'], 'table_rows': 5, 'snapshot_id': report['snapshot_id']}
                if ticker == 'COST':
                    app.text_area[0].set_value(memo + '\n\nROE was 40.0%.').run()
                    assert not app.exception
                    assert '1 unsupported' in app.error[0].value
                    assert app.dataframe[-1].value.iloc[0]['number'] == '40.0%'
                    assert next(b for b in app.button if b.label == 'Save reviewed memo').disabled
                    result['hand_typed_probe'] = {'text': '40.0%', 'flagged': True, 'save_blocked': True}
                    (ROOT / 'validation' / 'COST_unsupported_number_probe.md').write_text(
                        '# Hand-typed number probe\n\nThe Streamlit AppTest entered `ROE was 40.0%.` after the real COST memo. '
                        'The app listed `40.0%` as an unsupported numerical occurrence and disabled saving. '
                        'The intentional error was tested in a temporary copy; the submitted memo remains clean.\n', encoding='utf-8')
                evidence['companies'][ticker] = result
    text = json.dumps(evidence, indent=2)
    (ROOT / 'validation' / 'live_app_results.json').write_text(text, encoding='utf-8')
    print(text)


if __name__ == '__main__':
    main()
