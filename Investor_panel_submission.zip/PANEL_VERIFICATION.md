# Known-answer verification and threshold probe

Recomputed from the saved SEC companyfacts response, not pasted into the app:

| Fiscal year end | Current ratio | Liabilities / equity |
|---|---:|---:|
| 2022-08-28 | 1.02 | 2.11 |
| 2023-09-03 | 1.07 | 1.75 |
| 2024-09-01 | 0.97 | 1.96 |
| 2025-08-31 | 1.03 | 1.64 |
| 2026-08-30 | 1.06 | 1.49 |

All supplied ratios and check outcomes match. Buffett passes 3/3, Graham 2/3, Burry 2/2. Graham's only failure is latest-year current ratio.

The skill's real check function accepts a threshold parameter. Running its CLI with `--current-ratio-threshold 1.0` changes COST's liquidity check to pass, so Graham passes 3/3. The same underlying facts and unrounded ratio are used; no missing input is filled in and no memo verdict is changed automatically.

Retained threshold: **2.0**, to preserve the original conservative liquidity screen and comparability rather than loosen the rule to obtain a pass. This line is also beneath Graham's COST memo. The default is stored in `graham-edgar/settings.json`; editing it and rebuilding the shared report changes the default for the panel. The CLI override is an isolated probe.

Evidence: `validation/COST_panel_known_answer.json`, `validation/COST_graham_threshold_1.txt`, and the 21-test suite.

## Selected company

The user selected Apple (AAPL). Its panel uses SEC 10-K facts for fiscal years ending 2022-09-24 through 2026-09-26. No fallback company was required because Apple files 10-Ks. A fund name or ticker was not supplied, so Apple's rank within a fund has not been independently verified. See `reports/AAPL_panel.md` and the three AAPL memo files.

## Partner work

For the no-AI explanation, open `graham-edgar/scripts/graham_checks.py` at `check_graham`. The missing-input branches are in that function. Explain it directly with your partner.

The bull/bear partner exercise is still to be done on the selected company. It has not been represented as completed by the AI.
