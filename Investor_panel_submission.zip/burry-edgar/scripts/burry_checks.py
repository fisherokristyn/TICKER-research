"""Burry's classroom checks on the shared EDGAR annual rows."""
import argparse
from decimal import Decimal
import json
from pathlib import Path


def check_burry(rows):
    cash = ('not known' if len(rows) != 5 or any(
        r[k]['value'] is None for r in rows for k in ('operating_cash_flow', 'net_income'))
        else 'pass' if all(r['operating_cash_flow']['value'] >= r['net_income']['value'] for r in rows) else 'fail')
    latest = rows[-1] if rows else {}
    liabilities = latest.get('liabilities', {}).get('value')
    equity = latest.get('equity', {}).get('value')
    leverage = ('not known' if liabilities is None or equity is None or equity <= 0
                else 'pass' if Decimal(str(liabilities)) <= 2 * Decimal(str(equity)) else 'fail')
    return {'Operating cash flow >= net income every year': cash,
            'Liabilities <= 2 times equity, latest year': leverage}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', required=True, type=Path)
    report = json.loads(parser.parse_args().report.read_text(encoding='utf-8'))
    print(report['report_text'])
    print('Burry checks on shared snapshot ' + report['snapshot_id'])
    for label, status in check_burry(report['rows']).items():
        print(f'{label}: {status}')
