---
name: burry-edgar
description: Apply Burry's cash-backing and leverage checks to a shared SEC 10-K report and write a skeptical business-quality memo. Use for Burry analysis or the investor panel, without stock prices.
---

# Burry business review

Use the sibling `buffett-edgar` downloader and rules to create the shared report if needed. All panel members must read the same `<TICKER>.json` and printed report, not independently refreshed data. Install `buffett-edgar`, `graham-edgar`, and `burry-edgar` together under the same skills directory; the shared downloader imports the bundled checks directly.

Run from this skill directory:

```powershell
python scripts/burry_checks.py --report C:/Users/krist/work/lab18/reports/COST.json
```

Substitute the ticker. Read the entire output. Code checks operating cash flow >= net income in every annual period and latest `Liabilities <= 2 * StockholdersEquity`. The cash check requires five periods and every cash-flow/net-income input. Leverage uses year-end balances, not debt alone. Missing inputs or nonpositive equity make leverage and its check `not known`. Use the same 10-K-only, annual-flow, tag-priority, latest-filing and fiscal-year-end rules as Buffett. Never estimate missing values.

Use [Burry's FAskills page](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/michael_burry.md) only for perspective: question cash backing, accounting quality and financial vulnerability. Never install FAskills or call its services. Classroom checks override its broader criteria. Passing checks do not prove clean accounting; suspicions are questions to investigate, not evidence of fraud. Without prices, do not make price targets or short recommendations.

Write an original short memo as a clearly labelled Burry-inspired AI simulation. Choose `Own the business`, `Watch it`, or `Pass` in a heading of the form `# COST — Watch it`. Save `<TICKER>_burry_memo.md` beside the shared report. Use only numerical strings printed in the report, correctly attached to metrics and dates. No invented scores, forecasts, or written-out quantities. Identify evidence that could overturn the verdict; do not force a bearish answer just because this is Burry.

Validate with the sibling `buffett-edgar/scripts/edgar.py --audit-memo <memo-path> --report <shared-json-path>`. Fix flags and review factual context. Save `snapshot_id` in `<TICKER>_burry_memo.snapshot` after review. The app reads the heading's verdict and checks all memos against this shared report.
