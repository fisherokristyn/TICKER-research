# Verification status

The reference in `reference_cost.csv` is the user's classroom answer, in USD millions. It is not a downloaded SEC response and is never copied into the live app's reports. Reference tests construct artificial XBRL-shaped inputs solely inside tests to exercise annual selection, arithmetic and checks. Passing those tests does not verify the live SEC source.

Run the offline tests:

```powershell
cd C:\Users\krist\work\lab18
.\.venv\Scripts\python.exe -m unittest test_rules.py test_reference.py test_app.py
```

For live proof, configure your real SEC User-Agent, run the skill for COST and JPM, then run:

```powershell
.\.venv\Scripts\python.exe verify_reference.py
```

The comparator checks all seven metrics for every COST date, converts dollar values to millions, compares ROE rounded to the reference's single decimal, and requires all three checks to pass. JPM requires capital spending and owner earnings to remain `not found` and both owner-earnings checks `not known`. A missing downloaded report is reported as blocked, not passed. If EDGAR differs from the reference, investigate the tags, periods and filing dates; do not change the source values to fit the reference.

The UI integration test types `40.0%` into a memo loaded against the classroom fixture, verifies the warning lists that exact occurrence, and confirms the unsupported memo cannot be saved. This demonstrates the warning mechanism independently of live retrieval.

Live COST and JPM reports have now been downloaded from SEC EDGAR. The live reference comparison passes for both companies with no mismatches. COST matches all supplied dollar amounts, and its ROE matches when rounded to the reference's single decimal. The saved JPM memo explicitly says it cannot judge owner earnings from the permitted data. See `validation/live_reference_results.json` and `validation/live_app_results.json` for machine-readable verification.

## Student exercises

- In a fresh browser-AI chat without this skill, use the supplied Costco question. Record whether it cites SEC filings, uses annual periods, uses year-end or average equity, and names its numerator. No comparison has been fabricated here.
- For the six-minute no-AI exercise, open `buffett-edgar/scripts/edgar.py` at `build_year_row`, with `source_value` and `calc` nearby. Do the explanation with your partner.
- Write your own decision in the app's field below the memo. The app saves it separately and can download the memo with that line appended. No personal judgment has been filled in on your behalf.
