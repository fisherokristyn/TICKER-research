# My request to my AI

Extend my working Lab 18 skill and Streamlit app into a Buffett, Graham and Burry business-quality panel. Preserve the chart, original metrics and checks, source tags, SEC-only downloads, memo editing/downloads, missing-value rules and personal decision field.

Use one shared SEC company-facts snapshot and the same five actual fiscal-year-end dates for every investor. Add Liabilities, AssetsCurrent and LiabilitiesCurrent as year-end instant facts. Compute current ratio and liabilities/equity in code with missing-input and nonpositive-denominator handling.

Create and install graham-edgar and burry-edgar skills alongside buffett-edgar. Their bundled Python scripts must compute the assigned checks on the exact shared rows. Graham checks latest current ratio >= 2, positive net income every year, and endpoint income growth. Burry checks operating cash flow >= net income every year and latest liabilities <= twice equity. Missing required inputs produce not known. Use unrounded inputs at thresholds.

Read their FAskills pages for the qualitative perspectives without installing FAskills or using its providers. Each skill writes its own short business memo using only printed numerical strings; the model judges the business, not its price. Do not force disagreement or turn checks mechanically into verdicts.

Show an investor-by-check panel table, each verdict, three memos side by side, and a number audit across all memos. Bind memos to the shared report snapshot and warn after refresh. Run COST, inspect the exact outcomes, test missing-data and boundary cases, preserve the JPM probe, and verify the app flags an unsupported number inserted into each investor's memo.
