"""Audit and bind the authored COST memos; export the panel without inventing judgments."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'buffett-edgar/scripts'))
from edgar import audit_memo
from panel_ui import verdict_from_memo

report = json.loads((ROOT / 'reports/COST.json').read_text(encoding='utf-8'))
result = {'ticker': 'COST', 'snapshot_id': report['snapshot_id'], 'investors': {}}
lines = ['# COST investor panel', '', 'All investors use the same downloaded SEC report. Verdicts are AI judgments about the business, not the price.', '',
         '| Investor | Check | Result |', '|---|---|---|']
for investor, checks in report['panel_checks'].items():
    name = 'COST_memo' if investor == 'Buffett' else f'COST_{investor.lower()}_memo'
    memo = (ROOT / 'reports' / (name + '.md')).read_text(encoding='utf-8')
    flags = audit_memo(memo, report)
    assert not flags, (investor, flags)
    verdict = verdict_from_memo(memo)
    assert verdict != 'not provided'
    (ROOT / 'reports' / (name + '.snapshot')).write_text(report['snapshot_id'], encoding='utf-8')
    result['investors'][investor] = {'checks': checks, 'verdict': verdict, 'unsupported_numbers': flags,
                                    'memo': name + '.md'}
    for label, status in checks.items():
        lines.append(f'| {investor} | {label} | {status} |')
lines += ['', '| Investor | Verdict |', '|---|---|']
lines += [f"| {name} | {data['verdict']} |" for name, data in result['investors'].items()]
lines += ['', 'Graham’s liquidity criterion is the split: the latest current ratio is ' + report['rows'][-1]['current_ratio']['display'] +
          '. Buffett’s profitability/owner-earnings checks and Burry’s cash-backing/leverage checks pass. Different questions can support different judgments on the same facts.',
          '', 'Agreement is not independent corroboration: these are model-generated perspectives on a common dataset. Review the underlying claims and the missing evidence.', '']
(ROOT / 'reports/COST_panel.md').write_text('\n'.join(lines), encoding='utf-8')
(ROOT / 'validation/COST_panel_results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
