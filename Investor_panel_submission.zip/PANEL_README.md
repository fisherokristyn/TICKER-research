# Investor panel extension

Run the existing app with `python -m streamlit run app.py`. Use the sidebar's **Jump to investor panel** link to see the eight checks and the three memo columns. The original chart, Buffett checks, evidence table, provenance, memo editor, decision field and downloads remain available.

`PANEL_REQUEST.md` contains the authored build request. Skills are installed together under `C:/Users/krist/.agents/skills`: `buffett-edgar`, `graham-edgar`, and `burry-edgar`. Keep the folders together when copying or installing. Graham and Burry bundle pure check functions that the shared downloader calls directly, and command-line entry points that read the same saved report. No commercial source or FAskills installation is used.

The downloader adds year-end `Liabilities`, `AssetsCurrent`, and `LiabilitiesCurrent`. Current ratio and liabilities/equity use year-end balances; nonpositive denominators or missing inputs yield `not known`. Checks compare unrounded inputs. Annual tests require five periods; endpoint growth checks require the endpoints; latest-year checks use the latest selected period. Missing data always makes the affected check `not known`, even if another input would independently fail it.

The saved COST panel is in `reports/COST_panel.md`. The independent authored memos are `COST_memo.md`, `COST_graham_memo.md`, and `COST_burry_memo.md`. Each uses only numbers from the same printed report and is bound to its snapshot ID. These are distinct perspectives written by the AI, not independent experts or separate model runs. The verdicts come from the memo headings, not a rule counting passed checks.

The app audits edited text in every column. Unsupported numbers are listed with investor, line, and context. Saving that memo is disabled until corrected. Changing source data causes a snapshot warning, and a missing memo is shown as missing, never filled with a template.

Tests:

```powershell
.\.venv\Scripts\python.exe -m unittest test_rules.py test_reference.py test_app.py test_panel.py
.\.venv\Scripts\python.exe verify_reference.py
.\.venv\Scripts\python.exe verify_live_app.py
```

The tests cover exact thresholds, near-threshold rounding, zero/negative denominators, missing inputs, annual versus instant periods, the Lab 18 COST/JPM probes, and unsupported numbers injected into every memo editor. `finalize_panel.py` audits the authored COST memos and exports their actual verdicts.

Sources: [Graham](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/ben_graham.md), [Burry](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/michael_burry.md), [Streamlit columns](https://docs.streamlit.io/develop/api-reference/layout/st.columns).
