# My request to my AI

Build a reusable `buffett-edgar` skill and a local Streamlit app for the Lab 18 assignment. Install the skill where Codex discovers local skills, with a name and description in SKILL.md. Bundle a Python script that resolves a ticker using SEC company_tickers.json and fetches its companyfacts JSON, using my real name and email as the User-Agent, without keys or commercial services.

Apply the exact classroom tag priorities, annual-period, latest-filing, year-end equity, missing-data, ROE and owner-earnings rules. Print the last five fiscal-year-end dates, every required metric and its source tags, and compute the three checks in code. Keep source filing dates and accession numbers so I can inspect the evidence.

Read FAskills' Buffett page only for the qualitative framework; never install it or call its data providers. Use the new skill on COST. Write an AI-simulated Buffett-style business memo choosing own the business, watch it, or pass, using only printed numbers. Save it as Markdown, without stock prices or valuation.

Build an app with the required SEC/AI/learning disclaimer, a two-series owner-earnings/net-income chart, the five-year table, source tags, three checks, and the saved memo. Flag every numerical occurrence in the memo absent from the script's printed data. Allow another ticker and another AI-authored memo without requiring an AI API key. Test missing inputs, annual-period filtering, filing precedence, nonpositive equity, and unsupported memo numbers. Run and fix the app. Verify COST against the expected FY2022–FY2026 range, but report any source discrepancy instead of inventing future years or forcing an upward trend.

At twenty minutes, open Brightspace > Quizzes > Lab 18 if an accessible course session is available; do not answer or submit the quiz.
