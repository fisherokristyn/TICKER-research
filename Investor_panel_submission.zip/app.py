"""Run with: python -m streamlit run app.py"""
import json
import os
from pathlib import Path
import sys

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'buffett-edgar' / 'scripts'))
from edgar import LABELS, audit_memo, build, ticker_symbol
from panel_ui import render_panel

REPORTS = Path(os.getenv('BUFFETT_REPORTS_DIR', str(ROOT / 'reports')))
REPORTS.mkdir(exist_ok=True)
st.set_page_config(page_title='The business, not the price', page_icon='📖', layout='wide')
st.title('The business, not the price')
st.caption('data from SEC EDGAR; built with AI help, a learning demonstration, not investment advice.')

with st.sidebar:
    st.header('Business review')
    st.markdown('[Jump to investor panel](#investor-panel)')
    ticker_input = st.text_input('Ticker', value=st.query_params.get('ticker', 'COST'), key='ticker')
    user_agent = st.text_input('SEC User-Agent: your name and email', value=os.getenv('SEC_USER_AGENT', ''), key='user_agent')
    st.caption('Used only to identify SEC requests. No API key needed.')
    refresh = st.button('Fetch latest SEC facts', type='primary')
    st.divider()
    st.write('Annual flows · year-end equity · latest filing per tag')
    st.write('Owner earnings = operating cash flow − capital spending')
    st.caption('This classroom proxy does not estimate maintenance capital spending.')

try:
    ticker = ticker_symbol(ticker_input)
except ValueError as exc:
    st.warning(str(exc))
    st.stop()

path = REPORTS / f'{ticker}.json'
if refresh:
    try:
        with st.spinner('Reading SEC filings and computing the checks…'):
            build(ticker, user_agent, REPORTS, refresh=True)
        st.success('SEC facts downloaded and calculations saved.')
    except (ValueError, RuntimeError, OSError, KeyError) as exc:
        st.error(str(exc))
        st.stop()

if not path.exists():
    st.info('Enter your SEC User-Agent and fetch facts to begin. Existing saved reports load without a network request.')
    st.stop()

try:
    report = json.loads(path.read_text(encoding='utf-8'))
except (OSError, ValueError) as exc:
    st.error(f'Cannot read saved report: {exc}')
    st.stop()

st.subheader(f"{report['company']} · {ticker}")
st.caption(f"Saved snapshot: {report['retrieved_at']} · Fiscal years are labelled by actual year-end date.")
if len(report['rows']) < 5:
    st.warning('Fewer than five annual periods are available. The checks are not known.')

chart = pd.DataFrame([{
    'Fiscal year end': r['fiscal_year_end'],
    'Owner earnings': r['owner_earnings']['value'],
    'Net income': r['net_income']['value'],
} for r in report['rows']]).set_index('Fiscal year end')
st.line_chart(chart, color=['#137c66', '#4263a8'], y_label='USD', height=330)
st.caption('Missing values remain gaps; no estimates or interpolation are added to the data.')

st.subheader('The three checks')
for column, (label, result) in zip(st.columns(3), report['checks'].items()):
    with column:
        st.metric(label, result.upper())
st.caption('Checks use unrounded values. A passing screen is evidence for judgment, not a business verdict.')

st.subheader('Five-year evidence')
available_metrics = [key for key in LABELS if all(key in r for r in report['rows'])]
table = pd.DataFrame([{'Fiscal year end': r['fiscal_year_end'], **{LABELS[k]: r[k]['display'] for k in available_metrics}}
                      for r in report['rows']])
st.dataframe(table, hide_index=True, width='stretch')
st.caption('Dollar amounts are USD, not millions. ROE is a percentage; current ratio and liabilities/equity are multiples. Equity is measured at year end.')

with st.expander('XBRL tags and filing evidence'):
    provenance = []
    for r in report['rows']:
        for metric in available_metrics:
            c = r[metric]
            provenance.append({'Fiscal year end': r['fiscal_year_end'], 'Metric': LABELS[metric],
                               'XBRL tag / input tags': c['tag'], 'Filed': c.get('filed', 'calculated' if c.get('derived') else 'not found'),
                               'Accession': c.get('accession', ''), 'Annual start': c.get('start', ''),
                               'Notes': c.get('reason', '')})
    st.dataframe(pd.DataFrame(provenance), hide_index=True, width='stretch')
    st.link_button('SEC company facts JSON', report['source'])
    st.code(report['report_text'], language=None)

st.subheader('The AI memo')
st.caption('Buffett-inspired AI simulation. Business quality only; no price assessment.')
memo_path = REPORTS / f'{ticker}_memo.md'
binding_path = REPORTS / f'{ticker}_memo.snapshot'
saved_memo = memo_path.read_text(encoding='utf-8-sig') if memo_path.exists() else ''
upload = st.file_uploader('Load an AI-written Markdown memo for this ticker', type=['md'], key=f'upload_{ticker}')
try:
    initial_memo = upload.getvalue().decode('utf-8-sig') if upload else saved_memo
except UnicodeDecodeError:
    st.error('The memo must be a UTF-8 Markdown file.')
    st.stop()

if not initial_memo:
    st.info(f'Ask Codex to use $buffett-edgar on {ticker} and save {ticker}_memo.md in the reports folder. The app does not invent a memo.')
    st.download_button('Download printed facts for your AI', report['report_text'], file_name=f'{ticker}_facts.txt')

memo = st.text_area('Memo text — edit to test the number checker', value=initial_memo, height=220,
                    key=f"memo_{ticker}_{report['snapshot_id']}_{upload.file_id if upload else 'saved'}")
if memo:
    if saved_memo and not upload and (not binding_path.exists() or binding_path.read_text().strip() != report['snapshot_id']):
        st.warning('This memo has not been linked to the current facts snapshot. Review it against the table before saving.')
    flags = audit_memo(memo, report)
    if flags:
        st.error(f'{len(flags)} unsupported numerical occurrence(s). Every occurrence is listed below.')
        st.dataframe(pd.DataFrame(flags), hide_index=True, width='stretch')
    else:
        st.success('No unsupported numerical occurrences found.')
    st.caption('The audit checks printed numerical strings, including dates, signs and percent units. Spelled-out quantities are flagged conservatively. It cannot verify that an allowed number is used in the correct context.')
    st.markdown(memo)
    if st.button('Save reviewed memo', disabled=bool(flags)):
        memo_path.write_text(memo, encoding='utf-8')
        binding_path.write_text(report['snapshot_id'], encoding='utf-8')
        st.success(f'Saved {memo_path.name}')
    st.download_button('Download memo', memo, file_name=f'{ticker}_memo.md', mime='text/markdown')
    decision_path = REPORTS / f'{ticker}_decision.md'
    decision = st.text_input('Your decision — do you trust the verdict, and why?',
                             value=decision_path.read_text(encoding='utf-8') if decision_path.exists() else '',
                             key=f'decision_{ticker}',
                             placeholder='Write your own one-line decision here.')
    if st.button('Save my decision', disabled=not decision.strip()):
        decision_path.write_text(decision.strip(), encoding='utf-8')
        st.success('Your decision is saved beneath the memo.')
    if decision.strip():
        st.markdown(f'**Your decision:** {decision.strip()}')
        st.download_button('Download memo with my decision', memo + '\n\nYour decision: ' + decision.strip() + '\n',
                           file_name=f'{ticker}_memo_and_decision.md', mime='text/markdown')

render_panel(report, REPORTS, ticker, memo)

st.download_button('Download evidence JSON', path.read_bytes(), file_name=path.name, mime='application/json')
with st.expander('Sources and rules'):
    st.markdown('[SEC EDGAR API docs](https://www.sec.gov/search-filings/edgar-application-programming-interfaces) · '
                '[Buffett framework page](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/warren_buffett.md) · '
                '[Graham framework page](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/ben_graham.md) · '
                '[Burry framework page](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/michael_burry.md) · '
                '[Streamlit docs](https://docs.streamlit.io)')
    st.write('Only 10-K facts in USD; annual flows span 350–380 days. Preferred tags are tried in the assigned order; '
             'the latest filing wins within the first available tag. Missing source values print not found; '
             'owner earnings with missing inputs prints not found; ROE with missing inputs or nonpositive equity '
             'prints not known. Checks with missing required inputs print not known.')
