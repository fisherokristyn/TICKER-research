"""Bundle the lab artifacts without the Python environment, contact identity or logs."""
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
names = ['app.py', 'requirements.txt', 'README.md', 'REQUEST.md', 'VALIDATION.md', 'SUBMIT.md',
         'reference_cost.csv', 'verify_reference.py', 'verify_live_app.py',
         'test_rules.py', 'test_reference.py', 'test_app.py', 'package_submission.py']
paths = [root / name for name in names]
for name in ['buffett-edgar', 'reports', 'validation']:
    paths.extend(p for p in (root / name).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
destination = root / 'Lab18_submission.zip'
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(paths):
        archive.write(path, path.relative_to(root))
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None
    print(f'{destination}\n{len(archive.namelist())} files; archive integrity verified.')
