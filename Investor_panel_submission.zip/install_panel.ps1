$ErrorActionPreference = 'Stop'
$labRoot = 'C:\Users\krist\work\lab18'
$skillRoot = 'C:\Users\krist\.agents\skills'
$labPython = Join-Path $labRoot '.venv\Scripts\python.exe'
$validator = 'C:\Users\krist\.codex\skills\.system\skill-creator\scripts\quick_validate.py'
foreach ($skillName in @('buffett-edgar', 'graham-edgar', 'burry-edgar')) {
    & $labPython $validator (Join-Path $labRoot $skillName)
    if ($LASTEXITCODE -ne 0) { throw "Validation failed: $skillName" }
}
foreach ($skillName in @('buffett-edgar', 'graham-edgar', 'burry-edgar')) {
    $sourcePath = Join-Path $labRoot $skillName
    $targetPath = Join-Path $skillRoot $skillName
    New-Item -ItemType Directory -Path (Join-Path $targetPath 'scripts') -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $sourcePath 'SKILL.md') -Destination (Join-Path $targetPath 'SKILL.md')
    if (Test-Path -LiteralPath (Join-Path $sourcePath 'settings.json')) {
        Copy-Item -LiteralPath (Join-Path $sourcePath 'settings.json') -Destination (Join-Path $targetPath 'settings.json')
    }
    foreach ($scriptFile in Get-ChildItem -LiteralPath (Join-Path $sourcePath 'scripts') -Filter '*.py' -File) {
        Copy-Item -LiteralPath $scriptFile.FullName -Destination (Join-Path $targetPath ('scripts\' + $scriptFile.Name))
    }
    Write-Output "Installed $skillName"
}
try {
    $appHealth = (Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8501/_stcore/health' -TimeoutSec 3).Content
} catch { $appHealth = '' }
if ($appHealth -ne 'ok') {
    $process = Start-Process -FilePath $labPython -ArgumentList @('-m','streamlit','run',(Join-Path $labRoot 'app.py'),'--server.headless','true','--server.address','127.0.0.1','--server.port','8501','--browser.gatherUsageStats','false') -WorkingDirectory $labRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $labRoot 'panel.stdout.log') -RedirectStandardError (Join-Path $labRoot 'panel.stderr.log') -PassThru
    Write-Output "Started Streamlit PID $($process.Id)"
} else { Write-Output 'Streamlit is running at http://127.0.0.1:8501' }
