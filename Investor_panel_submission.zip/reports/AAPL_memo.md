# AAPL — Watch it

*Buffett-inspired AI simulation; business quality only.*

I would watch it. Apple passes the prescribed profitability and owner-earnings checks. Owner earnings rise from $111,443,000,000 at 2022-09-24 to $136,056,000,000 at 2026-09-26 and remain positive throughout the reported periods. That is encouraging evidence of cash left after capital spending.

I would not confuse a high return on book equity with proof of an enduring competitive advantage. Latest ROE is 117.92%, but that measure depends on the size of the equity base. Latest liabilities/equity is 2.61, and current ratio is 1.02; those balances deserve attention alongside earning power.

The annual cash record also deserves scrutiny: at 2025-09-27, operating cash flow of $111,482,000,000 is below net income of $112,010,000,000. I would want to understand that reconciliation and the durability of customer demand before choosing to own the business. The numerical screen does not establish the moat, management's capital-allocation quality, or a sensible stock price.
