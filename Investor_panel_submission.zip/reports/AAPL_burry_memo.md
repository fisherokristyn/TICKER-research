# AAPL — Pass

*Burry-inspired AI simulation; business quality only.*

I would pass for now pending further investigation. At 2025-09-27, operating cash flow of $111,482,000,000 is below net income of $112,010,000,000, so the requirement that cash flow cover income every year fails. The cash-flow reconciliation is the place to investigate whether timing or other adjustments explain that difference; the difference alone is not evidence of manipulation.

Latest liabilities are $292,455,000,000 against equity of $112,093,000,000 at 2026-09-26. Liabilities/equity is 2.61, above the limit of 2, so the leverage check also fails. These are total liabilities, not debt alone; their composition and maturity matter before drawing a distress conclusion.

The counterevidence is substantial: latest operating cash flow of $145,097,000,000 exceeds net income of $132,175,000,000, and owner earnings are $136,056,000,000. I would reconsider after examining the earlier cash shortfall and the nature of the obligations. The screen supports further investigation, not a fraud accusation, a short recommendation, or a stock-price target.
