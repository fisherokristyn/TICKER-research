# AAPL investor panel

Company selected by user; fund holding rank not independently verified.

| Investor | Check | Result |
|---|---|---|
| Buffett | ROE >= 15% every year | pass |
| Buffett | Owner earnings > 0 every year | pass |
| Buffett | Owner earnings grew, first year to last | pass |
| Graham | Current ratio >= 2, latest year | fail |
| Graham | Net income > 0 every year | pass |
| Graham | Net income grew, first year to last | pass |
| Burry | Operating cash flow >= net income every year | fail |
| Burry | Liabilities <= 2 times equity, latest year | fail |

| Investor | Verdict |
|---|---|
| Buffett | watch it |
| Graham | pass |
| Burry | pass |

The same facts support different emphases. Checks are code-computed; verdicts are AI judgments, not independent expert votes. No stock-price assessment is included.
