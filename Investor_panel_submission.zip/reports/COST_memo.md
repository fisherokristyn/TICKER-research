# COST — Watch it

*Buffett-inspired AI simulation; business quality only.*

I like a business that earns well and leaves cash after capital spending. Costco passes the prescribed checks: ROE stays above 15%, owner earnings remain positive, and owner earnings finish above where they began. Owner earnings rose from $3,501,000,000 at 2022-08-28 to $9,382,000,000 at 2026-08-30. Net income also rose, from $5,844,000,000 to $9,226,000,000 over those dates.

I would watch it. These results earn further investigation, but a strong financial record does not establish why customers stay or whether competitors can erode the advantage. The downloaded facts also do not establish management's integrity or the returns earned on particular capital-allocation decisions. I would want evidence of durable customer value and disciplined reinvestment before choosing to own the business.

The cash record is encouraging, but it is not uninterrupted growth: owner earnings were $6,745,000,000 at 2023-09-03 and $6,629,000,000 at 2024-09-01. This measure subtracts all reported capital spending; it does not separately identify maintenance needs. Evidence that the apparent earning power depends on deferred spending or a weakening competitive position would make me reconsider. This verdict makes no claim about the stock's price.
