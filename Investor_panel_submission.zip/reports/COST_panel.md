# COST investor panel

All investors use the same downloaded SEC report. Verdicts are AI judgments about the business, not the price.

| Investor | Check | Result |
|---|---|---|
| Buffett | ROE >= 15% every year | pass |
| Buffett | Owner earnings > 0 every year | pass |
| Buffett | Owner earnings grew, first year to last | pass |
| Graham | Current ratio >= 2, latest year | fail |
| Graham | Net income > 0 every year | pass |
| Graham | Net income grew, first year to last | pass |
| Burry | Operating cash flow >= net income every year | pass |
| Burry | Liabilities <= 2 times equity, latest year | pass |

| Investor | Verdict |
|---|---|
| Buffett | watch it |
| Graham | pass |
| Burry | watch it |

Graham’s liquidity criterion is the split: the latest current ratio is 1.06. Buffett’s profitability/owner-earnings checks and Burry’s cash-backing/leverage checks pass. Different questions can support different judgments on the same facts.

Agreement is not independent corroboration: these are model-generated perspectives on a common dataset. Review the underlying claims and the missing evidence.
