---
name: graham-edgar
description: Apply Graham's liquidity and earnings checks to a shared SEC 10-K report and write a conservative business-quality memo. Use for Graham analysis or the investor panel, without stock prices.
---

# Graham business review

The retained liquidity threshold is **2.0**, stored in `settings.json`. Keep it to preserve the original conservative liquidity screen and comparability; do not loosen it just to produce a pass. To run the required sensitivity probe on the same facts, add `--current-ratio-threshold 1.0` to the command below. This runs the skill's actual check code with the lower threshold without overwriting the default report. To retain a different threshold, edit `settings.json` and regenerate the shared report and all memos; the report prints the active threshold. Record the retained threshold and rationale beneath Graham's memo.

Use the installed sibling `buffett-edgar` downloader and rules to create the shared report if needed. All panel members must read the same `<TICKER>.json` and printed report, not independently refreshed data. The `buffett-edgar`, `graham-edgar`, and `burry-edgar` folders must be installed together under the same skills directory. The shared downloader imports the bundled check functions directly.

Run from this skill directory:

```powershell
python scripts/graham_checks.py --report C:/Users/krist/work/lab18/reports/COST.json
```

Substitute the ticker. Read the entire printed output. The code checks latest current ratio >= 2, positive net income in every annual period, and growth in net income from earliest to latest period. Annual checks require five periods; growth requires both endpoints. Current ratio uses year-end `AssetsCurrent / LiabilitiesCurrent`. Missing inputs or nonpositive current liabilities make the ratio and liquidity check `not known`. Source values not found remain `not found`. Use the same 10-K-only, annual-flow, tag-priority, latest-filing and fiscal-year-end rules as Buffett. Never estimate missing values.

Use [Graham's FAskills page](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/ben_graham.md) only for perspective: emphasize liquidity, financial resilience, earnings stability and a conservative interpretation of evidence. Do not install FAskills or call its services. Classroom checks override its broader criteria. Without prices, do not claim a bargain, margin of safety, or buy/sell price. A failed liquidity check is not by itself proof of distress; identify what the limited data leave unresolved.

Write an original short memo as a clearly labelled Graham-inspired AI simulation. Choose `Own the business`, `Watch it`, or `Pass` in a heading of the form `# COST — Watch it`. Save `<TICKER>_graham_memo.md` in the reports directory. Use numerical strings from the shared printed report only, with correct periods and metrics; no invented scores, forecasts, or written-out quantities. Distinguish business judgment from the code's check outcomes, and do not force disagreement with the other memos.

Validate it with the sibling `buffett-edgar/scripts/edgar.py --audit-memo <memo-path> --report <shared-json-path>`. Correct every flagged number and review factual context. Save the report's `snapshot_id` in `<TICKER>_graham_memo.snapshot` after review. The app displays the verdict from the heading and audits the memo against the same report as the other investors.
