"""Graham's classroom checks on the shared EDGAR annual rows."""
import argparse
from decimal import Decimal
import json
from pathlib import Path


def current_ratio_threshold(override=None):
    if override is None:
        settings = Path(__file__).resolve().parents[1] / 'settings.json'
        override = json.loads(settings.read_text(encoding='utf-8'))['current_ratio_threshold']
    threshold = Decimal(str(override))
    if not threshold.is_finite() or threshold <= 0:
        raise ValueError('The current-ratio threshold must be finite and positive.')
    return threshold


def check_graham(rows, threshold=None):
    threshold = current_ratio_threshold(threshold)
    latest = rows[-1] if rows else {}
    assets = latest.get('current_assets', {}).get('value')
    liabilities = latest.get('current_liabilities', {}).get('value')
    liquidity = ('not known' if assets is None or liabilities is None or liabilities <= 0
                 else 'pass' if Decimal(str(assets)) >= threshold * Decimal(str(liabilities)) else 'fail')
    incomes = [r['net_income']['value'] for r in rows]
    positive = ('not known' if len(rows) != 5 or any(v is None for v in incomes)
                else 'pass' if all(v > 0 for v in incomes) else 'fail')
    growth = ('not known' if len(rows) != 5 or incomes[0] is None or incomes[-1] is None
              else 'pass' if incomes[-1] > incomes[0] else 'fail')
    return {f'Current ratio >= {threshold.normalize():f}, latest year': liquidity,
            'Net income > 0 every year': positive,
            'Net income grew, first year to last': growth}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', required=True, type=Path)
    parser.add_argument('--current-ratio-threshold', help='Explicit design-choice probe; does not overwrite the saved shared report.')
    args = parser.parse_args()
    report = json.loads(args.report.read_text(encoding='utf-8'))
    print(report['report_text'])
    print('Graham checks on shared snapshot ' + report['snapshot_id'])
    print('Active threshold: ' + str(current_ratio_threshold(args.current_ratio_threshold)))
    for label, status in check_graham(report['rows'], args.current_ratio_threshold).items():
        print(f'{label}: {status}')
