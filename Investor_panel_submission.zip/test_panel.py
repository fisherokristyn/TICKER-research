"""Panel boundary tests and live memo/UI verification."""
import copy
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from test_rules import fixture, analyze
from edgar import check_graham, check_burry, audit_memo
from panel_ui import verdict_from_memo
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parent


def panel_fixture():
    facts = fixture()
    for tag, value in [('AssetsCurrent', 200), ('LiabilitiesCurrent', 100), ('Liabilities', 200)]:
        concept = copy.deepcopy(facts['facts']['us-gaap']['StockholdersEquity'])
        for f in concept['units']['USD']:
            f['val'] = value
        facts['facts']['us-gaap'][tag] = concept
    return facts


class PanelRules(unittest.TestCase):
    def test_threshold_design_choice_does_not_fill_missing_inputs(self):
        report = analyze(panel_fixture(), 'TEST')
        report['rows'][-1]['current_assets']['value'] = 106
        self.assertEqual(list(check_graham(report['rows'], '2.0').values())[0], 'fail')
        self.assertEqual(list(check_graham(report['rows'], '1.0').values())[0], 'pass')
        report['rows'][-1]['current_assets']['value'] = None
        self.assertEqual(list(check_graham(report['rows'], '1.0').values())[0], 'not known')
        for invalid in ['0', '-1', 'NaN', 'Infinity']:
            with self.assertRaises(ValueError):
                check_graham(report['rows'], invalid)

    def test_exact_boundaries_and_flat_income(self):
        report = analyze(panel_fixture(), 'TEST')
        self.assertEqual(list(report['panel_checks']['Graham'].values()), ['pass', 'pass', 'fail'])
        self.assertEqual(list(report['panel_checks']['Burry'].values()), ['pass', 'pass'])

    def test_checks_do_not_round(self):
        facts = panel_fixture()
        facts['facts']['us-gaap']['AssetsCurrent']['units']['USD'][-1]['val'] = 199.999
        facts['facts']['us-gaap']['Liabilities']['units']['USD'][-1]['val'] = 200.001
        report = analyze(facts, 'TEST')
        self.assertEqual(report['rows'][-1]['current_ratio']['display'], '2.00')
        self.assertEqual(report['rows'][-1]['liabilities_to_equity']['display'], '2.00')
        self.assertEqual(list(report['panel_checks']['Graham'].values())[0], 'fail')
        self.assertEqual(list(report['panel_checks']['Burry'].values())[1], 'fail')

    def test_missing_and_invalid_denominators(self):
        facts = panel_fixture()
        for value in [0, -10]:
            facts['facts']['us-gaap']['StockholdersEquity']['units']['USD'][-1]['val'] = value
            facts['facts']['us-gaap']['LiabilitiesCurrent']['units']['USD'][-1]['val'] = value
            report = analyze(facts, 'TEST')
            self.assertEqual(report['rows'][-1]['current_ratio']['display'], 'not known')
            self.assertEqual(report['rows'][-1]['liabilities_to_equity']['display'], 'not known')
            self.assertEqual(list(check_graham(report['rows']).values())[0], 'not known')
            self.assertEqual(list(check_burry(report['rows']).values())[1], 'not known')
        del facts['facts']['us-gaap']['Liabilities']
        report = analyze(facts, 'TEST')
        self.assertEqual(report['rows'][-1]['liabilities']['display'], 'not found')
        self.assertEqual(list(check_burry(report['rows']).values())[1], 'not known')

    def test_latest_checks_ignore_old_gaps_and_annual_checks_require_inputs(self):
        facts = panel_fixture()
        facts['facts']['us-gaap']['AssetsCurrent']['units']['USD'].pop(0)
        facts['facts']['us-gaap']['NetIncomeLoss']['units']['USD'].pop(2)
        report = analyze(facts, 'TEST')
        self.assertEqual(list(check_graham(report['rows']).values()), ['pass', 'not known', 'fail'])
        self.assertEqual(list(check_burry(report['rows']).values()), ['not known', 'pass'])

    def test_cash_equality_passes_shortfall_fails(self):
        facts = panel_fixture()
        flows = facts['facts']['us-gaap']['NetCashProvidedByUsedInOperatingActivities']['units']['USD']
        flows[0]['val'] = 20
        self.assertEqual(list(check_burry(analyze(facts, 'TEST')['rows']).values())[0], 'pass')
        flows[0]['val'] = 19
        self.assertEqual(list(check_burry(analyze(facts, 'TEST')['rows']).values())[0], 'fail')


class LiveCostPanel(unittest.TestCase):
    def test_memos_and_warning_in_every_column(self):
        report = json.loads((ROOT / 'reports/COST.json').read_text(encoding='utf-8'))
        self.assertEqual(list(report['panel_checks']['Graham'].values()), ['fail', 'pass', 'pass'])
        self.assertEqual(list(report['panel_checks']['Burry'].values()), ['pass', 'pass'])
        names = ['COST_memo', 'COST_graham_memo', 'COST_burry_memo']
        memos = [(ROOT / 'reports' / (name + '.md')).read_text(encoding='utf-8') for name in names]
        self.assertEqual([verdict_from_memo(m) for m in memos], ['watch it', 'pass', 'watch it'])
        for memo in memos:
            self.assertEqual(audit_memo(memo, report), [])
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory)
            (target / 'COST.json').write_text(json.dumps(report), encoding='utf-8')
            for name, memo in zip(names, memos):
                (target / (name + '.md')).write_text(memo, encoding='utf-8')
                (target / (name + '.snapshot')).write_text(report['snapshot_id'], encoding='utf-8')
            with patch.dict(os.environ, {'BUFFETT_REPORTS_DIR': directory}):
                app = AppTest.from_file(str(ROOT / 'app.py'), default_timeout=30).run()
                self.assertFalse(app.exception)
                self.assertFalse(app.error)
                tables = [d.value for d in app.dataframe if 'Investor' in d.value.columns]
                self.assertEqual(tables[0].shape, (8, 3))
                self.assertEqual(len(app.text_area), 3)
                # Check each editor independently, then all simultaneously.
                for index in range(3):
                    app.text_area[index].set_value(memos[index] + '\nROE was 40.0%.').run()
                    self.assertFalse(app.exception)
                    flags = app.dataframe[-1].value
                    self.assertEqual(len(flags), index + 1)
                    self.assertEqual(flags.iloc[-1]['Investor'], ['Buffett', 'Graham', 'Burry'][index])
                    self.assertEqual(flags.iloc[-1]['number'], '40.0%')
                for label in ['Save reviewed memo', 'Save Graham memo', 'Save Burry memo']:
                    self.assertTrue(next(b for b in app.button if b.label == label).disabled)


if __name__ == '__main__':
    unittest.main()
