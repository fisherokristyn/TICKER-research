# Lab 18 — The business, not the price

Read `REQUEST.md` for the authored build request. The skill source is `buffett-edgar/SKILL.md` with its bundled standard-library downloader in `scripts/edgar.py`.

## Run locally

```powershell
cd C:\Users\krist\work\lab18
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
$env:SEC_USER_AGENT = 'Your real name your-real-email@domain.com'
.\.venv\Scripts\python.exe buffett-edgar\scripts\edgar.py COST --output-dir reports
.\.venv\Scripts\python.exe -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501
```

The SEC identity shown above is a format example, not a valid identity to submit. Enter your own details. No identity is written into reports. Raw SEC responses are cached for a day; `--refresh` forces a fresh request. Errors never fall back to invented data.

Ask Codex: **Use $buffett-edgar on COST and save the memo in C:/Users/krist/work/lab18/reports.** Codex reads the printed facts and writes `reports/COST_memo.md`. The app displays that memo; another ticker can use a memo produced by the same skill or uploaded in the app. No AI API account is required for the app.

The table prints full USD amounts and ROE to two decimals. Checks compare unrounded inputs. Calculated metrics list their input tags. Every source cell includes its SEC filing date and accession. Tag priority is applied before latest-filing selection within that tag. Annual dates, not filing `fy`, identify fiscal years.

The memo checker conservatively flags numerical strings absent from printed data, including unsupported signs, percentages, dates and scaled units. Written-number words are flagged for review. It checks membership, not factual context, and does not establish that a reused number belongs to the asserted metric. Saved memos bind to a report snapshot; fresh data triggers a review warning if the snapshot changes.

## Tests

```powershell
.\.venv\Scripts\python.exe -m unittest test_rules.py
```

`test_rules.py` uses synthetic fixtures only; these are never saved as company reports.

Sources: [Codex skills](https://learn.chatgpt.com/docs/build-skills), [SEC API](https://www.sec.gov/search-filings/edgar-application-programming-interfaces), [ticker mapping](https://www.sec.gov/files/company_tickers.json), [Buffett page](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/warren_buffett.md), [Streamlit charts](https://docs.streamlit.io/develop/api-reference/charts/st.line_chart), [Streamlit tests](https://docs.streamlit.io/develop/api-reference/app-testing/st.testing.v1.apptest).
