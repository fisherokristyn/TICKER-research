"""Package the extended panel without replacing the original Lab 18 ZIP."""
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
files = [p for pattern in ('*.py', '*.md', '*.csv', 'requirements.txt', 'install_panel.ps1') for p in root.glob(pattern)]
for folder in ('buffett-edgar', 'graham-edgar', 'burry-edgar', 'reports', 'validation'):
    files.extend(p for p in (root / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
output = root / 'Investor_panel_submission.zip'
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(set(files)):
        archive.write(path, path.relative_to(root))
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    print(f'{output}\n{len(archive.namelist())} files; integrity verified.')
