# Hand-typed number probe

The Streamlit AppTest entered `ROE was 40.0%.` after the real COST memo. The app listed `40.0%` as an unsupported numerical occurrence and disabled saving. The intentional error was tested in a temporary copy; the submitted memo remains clean.
