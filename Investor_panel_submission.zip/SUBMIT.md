# Lab 18 submission files

The technical work is verified against downloaded SEC data:

- `buffett-edgar/`: SKILL.md and bundled downloader/calculator.
- `app.py` and `requirements.txt`: Streamlit app.
- `reports/COST_facts.txt`, `reports/COST.json`, `reports/COST_memo.md`: Costco results, tags, provenance, checks and AI memo.
- `reports/JPM_facts.txt`, `reports/JPM.json`, `reports/JPM_memo.md`: missing-data probe and explicit inability to judge owner earnings.
- `validation/live_reference_results.json`: live reference comparison, both pass.
- `validation/live_app_results.json` and `validation/COST_unsupported_number_probe.md`: real-data app checks and the flagged 40.0% probe.
- `reports/cache/`: original SEC JSON responses for reproducibility.
- `REQUEST.md`: the authored build request.

COST matches every supplied reference value after converting USD to USD millions and rounding ROE to the reference's single decimal. All three COST checks pass. JPM capital spending and owner earnings stay not found; the owner-earnings checks stay not known. Both clean memos pass the printed-number audit.

Before submitting individually:

- Add your own one-line trust decision below the COST memo. The app can save that line and download the combined memo, or you can append it directly to the Markdown file.
- Complete the fresh browser-AI comparison and the partner code explanation yourself as assigned. These have not been represented as completed.
- Submit the GitHub links requested by the lab, or use the file-upload option available in the quiz as appropriate. Nothing has been published to GitHub or submitted to Brightspace by the assistant.

No SEC contact identity is included in this package. To refresh data, provide your own real name and email in the app or SEC_USER_AGENT environment variable. Existing saved reports and memos load without a network request.
