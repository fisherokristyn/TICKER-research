"""Audit a selected company's three memos and verify their app display."""
import argparse
import json
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'buffett-edgar/scripts'))
from edgar import audit_memo, ticker_symbol
from panel_ui import verdict_from_memo

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('ticker')
ticker = ticker_symbol(parser.parse_args().ticker)
report = json.loads((ROOT / 'reports' / f'{ticker}.json').read_text(encoding='utf-8'))
result = {'ticker': ticker, 'selection': 'Company selected by user; fund holding rank not independently verified.',
          'snapshot_id': report['snapshot_id'], 'investors': {}}
memos = {}
for investor, checks in report['panel_checks'].items():
    name = f'{ticker}_memo' if investor == 'Buffett' else f'{ticker}_{investor.lower()}_memo'
    memo = (ROOT / 'reports' / f'{name}.md').read_text(encoding='utf-8')
    assert not audit_memo(memo, report), (investor, audit_memo(memo, report))
    verdict = verdict_from_memo(memo)
    assert verdict != 'not provided'
    memos[name] = memo
    (ROOT / 'reports' / f'{name}.snapshot').write_text(report['snapshot_id'], encoding='utf-8')
    result['investors'][investor] = {'checks': checks, 'verdict': verdict, 'unsupported_numbers': []}

with tempfile.TemporaryDirectory() as directory:
    target = Path(directory)
    (target / f'{ticker}.json').write_text(json.dumps(report), encoding='utf-8')
    for name, memo in memos.items():
        (target / f'{name}.md').write_text(memo, encoding='utf-8')
        (target / f'{name}.snapshot').write_text(report['snapshot_id'], encoding='utf-8')
    with patch.dict(os.environ, {'BUFFETT_REPORTS_DIR': directory}):
        app = AppTest.from_file(str(ROOT / 'app.py'), default_timeout=30)
        app.query_params['ticker'] = ticker
        app.run()
        assert not app.exception, app.exception
        assert not app.error, app.error
        assert app.text_input(key='ticker').value == ticker
        assert len(app.text_area) == 3
        panel = next(d.value for d in app.dataframe if 'Investor' in d.value.columns)
        assert len(panel) == 8
        for index, memo in enumerate(memos.values()):
            app.text_area[index].set_value(memo + '\nUnsupported ROE: 9999.9%.').run()
            assert not app.exception
            flags = app.dataframe[-1].value
            assert len(flags) == index + 1
            assert flags.iloc[-1]['Investor'] == ['Buffett', 'Graham', 'Burry'][index]
        result['app_verification'] = {'three_memos': True, 'eight_checks': True, 'number_flags_in_all_memos': True}

lines = [f'# {ticker} investor panel', '', result['selection'], '',
         '| Investor | Check | Result |', '|---|---|---|']
for investor, data in result['investors'].items():
    for label, status in data['checks'].items():
        lines.append(f'| {investor} | {label} | {status} |')
lines += ['', '| Investor | Verdict |', '|---|---|']
lines += [f"| {name} | {data['verdict']} |" for name, data in result['investors'].items()]
lines += ['', 'The same facts support different emphases. Checks are code-computed; verdicts are AI judgments, not independent expert votes. No stock-price assessment is included.', '']
(ROOT / 'reports' / f'{ticker}_panel.md').write_text('\n'.join(lines), encoding='utf-8')
(ROOT / 'validation' / f'{ticker}_panel_results.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
