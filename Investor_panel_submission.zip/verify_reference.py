"""Compare downloaded reports with the user's reference. Never generates company data."""
import csv
from decimal import Decimal, ROUND_HALF_UP
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def reference_rows():
    with (ROOT / 'reference_cost.csv').open(newline='', encoding='utf-8') as stream:
        return list(csv.DictReader(stream))


def compare_cost(report):
    findings = []
    rows = {r['fiscal_year_end']: r for r in report['rows']}
    expected = reference_rows()
    if sorted(rows) != [r['fiscal_year_end'] for r in expected]:
        findings.append('Fiscal-year-end dates differ from the reference.')
    for ref in expected:
        end = ref['fiscal_year_end']
        if end not in rows:
            findings.append(f'{end}: missing year')
            continue
        for key, text in ref.items():
            if key == 'fiscal_year_end':
                continue
            metric = 'roe' if key == 'roe_percent' else key
            value = rows[end][metric]['value']
            if value is None:
                findings.append(f'{end} {key}: missing value; expected {text}')
                continue
            actual = Decimal(str(value))
            if key == 'roe_percent':
                actual = (actual * 100).quantize(Decimal('.1'), rounding=ROUND_HALF_UP)
            else:
                actual /= 1_000_000
            if actual != Decimal(text):
                findings.append(f'{end} {key}: got {actual}; expected {text}')
    for label, status in report['checks'].items():
        if status != 'pass':
            findings.append(f'{label}: {status}; expected pass')
    return findings


def compare_jpm(report):
    findings = []
    if len(report['rows']) != 5:
        findings.append('Expected five annual periods.')
    for row in report['rows']:
        for metric in ('capital_spending', 'owner_earnings'):
            if row[metric]['display'] != 'not found':
                findings.append(f"{row['fiscal_year_end']} {metric}: expected not found, got {row[metric]['display']}")
    for label, status in report['checks'].items():
        if label.startswith('Owner earnings') and status != 'not known':
            findings.append(f'{label}: expected not known, got {status}')
    return findings


def main():
    result = {'reference_source': 'User-supplied classroom table; dollar columns are USD millions.', 'results': {}}
    for ticker, compare in [('COST', compare_cost), ('JPM', compare_jpm)]:
        path = ROOT / 'reports' / f'{ticker}.json'
        if not path.exists():
            result['results'][ticker] = {'status': 'blocked', 'reason': 'Live SEC report has not been downloaded.'}
            continue
        report = json.loads(path.read_text(encoding='utf-8'))
        mismatches = compare(report)
        result['results'][ticker] = {'status': 'fail' if mismatches else 'pass', 'mismatches': mismatches,
                                     'snapshot_id': report['snapshot_id']}
    folder = ROOT / 'validation'
    folder.mkdir(exist_ok=True)
    text = json.dumps(result, indent=2)
    (folder / 'live_reference_results.json').write_text(text, encoding='utf-8')
    print(text)
    return 0 if all(r['status'] == 'pass' for r in result['results'].values()) else 1


if __name__ == '__main__':
    raise SystemExit(main())
