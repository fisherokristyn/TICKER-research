"""Check the new classroom ratios and sensitivity probe against real saved SEC facts."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'buffett-edgar/scripts'))
from edgar import analyze, check_graham

expected = [
    ('2022-08-28', '1.02', '2.11'),
    ('2023-09-03', '1.07', '1.75'),
    ('2024-09-01', '0.97', '1.96'),
    ('2025-08-31', '1.03', '1.64'),
    ('2026-08-30', '1.06', '1.49'),
]
facts = json.loads((ROOT / 'reports/cache/CIK0000909832.json').read_text(encoding='utf-8'))
report = analyze(facts, 'COST')
actual = [(r['fiscal_year_end'], r['current_ratio']['display'], r['liabilities_to_equity']['display']) for r in report['rows']]
assert actual == expected, (actual, expected)
assert list(report['panel_checks']['Buffett'].values()) == ['pass', 'pass', 'pass']
assert list(report['panel_checks']['Graham'].values()) == ['fail', 'pass', 'pass']
assert list(report['panel_checks']['Burry'].values()) == ['pass', 'pass']
probe = check_graham(report['rows'], '1.0')
assert list(probe.values()) == ['pass', 'pass', 'pass']
# Retain the original threshold in the normal report; the probe cannot overwrite it.
(ROOT / 'reports/COST.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
(ROOT / 'reports/COST_facts.txt').write_text(report['report_text'], encoding='utf-8')
result = {'source': 'Saved raw SEC companyfacts response; recomputed with current code',
          'ratios': [{'fiscal_year_end': e, 'current_ratio': c, 'liabilities_to_equity': l} for e, c, l in actual],
          'all_ratios_match': True, 'baseline_checks': report['panel_checks'],
          'threshold_probe': {'threshold': '1.0', 'Graham': probe},
          'threshold_kept': '2.0',
          'reason': 'Preserve the original conservative liquidity screen and comparability, rather than fit the rule to COST.',
          'snapshot_id': report['snapshot_id']}
(ROOT / 'validation/COST_panel_known_answer.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
